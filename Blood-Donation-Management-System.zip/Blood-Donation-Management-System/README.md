# Blood-Donation-Management-System

To run this project, We have to follow 3(Three) steps:

-> 1st Step:
      
      We have to add MySql Driver in our project.

      To add this: 
          Right Click the   project -- > build path -- > configure build path
          then:
          In 'Libraries' Tab press 'Add External Jar' and Select your '.jar'.
      
      ** You will find the 'jar' file in the 'Driver' folder. **
      
      For More info, You may follow the link:
        https://stackoverflow.com/questions/17484764/java-lang-classnotfoundexception-com-mysql-jdbc-driver-in-eclipse
        
-> 2nd Step:
      
      We have to add initial databases to run this project.
      
      To add this, Follow this link:
        https://stackoverflow.com/questions/4546778/how-can-i-import-a-database-with-mysql-from-terminal
    
    ** You will find the Database file in the 'Database' folder. **
    
-> 3rd Step:
      
      To set-up your database username & password:
          Goto:
          src -> Database -> ConnectionDatabase.java
        
 -> One more thing:
 
      If you want to use this project as an 'Admin', you'll need admin approval key.
      By Default Admin Approval Key: 13579
      You can change it after logging as Admin in settings. 
        
                      
                      
                                                ******** Enjoy ********
