import Database.ConnectionDatabase;

public class DatabaseConnection extends ConnectionDatabase {

}
